#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h> 	
#include <unistd.h> 	


#define MYPORT 3456
#define BACKLOG 10
#define MAXDATASIZE 10000
/* the port users will be connecting to */
/* number of pending connections */
main()
{
int sockfd, new_fd,numbytes;
char buf[MAXDATASIZE];
/* listen on sock_fd,
new connection on new_fd */
struct sockaddr_in my_addr;
/* my address information */
struct sockaddr_in their_addr; /* client's address info */
int sin_size;
if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
{
perror("socket");
exit(1);
}
my_addr.sin_family = AF_INET;
my_addr.sin_port = htons(MYPORT);
my_addr.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */
bzero(&(my_addr.sin_zero), 8);
/* zero the rest */
if (bind(sockfd,(struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
{
perror("bind");
exit(1);
}
if (listen(sockfd, BACKLOG) == -1)
{
perror("listen");
exit(1);
}
while(1)
/* main accept() loop */
{
sin_size = sizeof(struct sockaddr_in);
if ((new_fd = accept(sockfd,(struct sockaddr *)&their_addr,&sin_size)) ==
-1)
{
perror("accept");
continue;
}
printf("server: got connection from %d\n",
inet_ntoa(their_addr.sin_addr));


if (!fork())
/* this is the child process */
{
if ((numbytes=recv(new_fd, buf, MAXDATASIZE, 0)) == -1)
{
perror("recv");
exit(1);
}
int n=numbytes,i,sent=0,word=0,ch=0;

buf[n] = '\0';
if(buf[n-1] != '.') {word++;sent++;}
printf("Received: %s",buf);
for(i=0; buf[i] != '\0'; i++){ch++;
if(buf[i] == '.'){sent++;}
}
for(i=0; buf[i] != '\0'; i++){
if((buf[i] == '.' && buf[i+1] == ' ') || (buf[i] == ' ' && buf[i-1] != '.') || (buf[i] == '.' && buf[i+1] != ' ')){word++;}}

if(ch > 0 && word ==0){word=1;}
/*
printf("\n%d\n",sent);
printf("\n%d\n",word);
printf("\n%d\n",ch);*/

/*
if (send(new_fd, "Hello, world!\n", 14, 0) == -1)
perror("send");*/
sleep(ch/50);
int tmp=htonl(sent);

write(new_fd, &tmp, sizeof(tmp));
//perror("send");
//close(new_fd);
//exit(0);
int tmpr=htonl(word);
write(new_fd, &tmpr, sizeof(tmpr));

int temp=htonl(ch);
write(new_fd, &temp, sizeof(temp));
}
close(new_fd); /* parent doesn't need this */
while(waitpid(-1,NULL,WNOHANG) > 0); /* clean up child processes */
}
close(new_fd);
}
