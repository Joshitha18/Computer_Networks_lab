#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define PORT 3456 /* the port client will be connecting to */
#define MAXDATASIZE 100 /* max number of bytes we can get at once */
int main(int argc, char *argv[])
{
int sockfd, numbytes;
char buf[MAXDATASIZE];
struct hostent *he;
struct sockaddr_in their_addr; /* client's address information */
if (argc != 2)
{
fprintf(stderr,"usage: client hostname\n");
exit(1);
}
if ((he=gethostbyname(argv[1])) == NULL)
{
herror("gethostbyname");
exit(1);
}
/* get the host info */
if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
{
perror("socket");
exit(1);
}
their_addr.sin_family = AF_INET;
their_addr.sin_port = htons(PORT);
their_addr.sin_addr = *((struct in_addr *)he->h_addr);
bzero(&(their_addr.sin_zero), 8);
if (connect(sockfd,(struct sockaddr *)&their_addr, sizeof(struct sockaddr)) ==
-1)
{
perror("connect");
exit(1);
}

printf("enter paragraph\n");
char para[10000];
scanf("%[^\n]s", para);
int len;
len=strlen(para);
//printf("len %d\n",len);
if (send(sockfd, para, len, 0) == -1)
perror("send");

int sen,w,c,tmp,temp,tmpr;

read(sockfd, &tmp, sizeof(tmp));
sen=ntohl(tmp);
printf("\nsentences: %d\n",sen);

read(sockfd, &temp, sizeof(temp));
w=ntohl(temp);
printf("words: %d\n",w);

read(sockfd, &tmpr, sizeof(tmpr));
c=ntohl(tmpr);
printf("characters: %d\n",c);

exit(0);
}

/*
sysad@sysad-XPS-13-9380:~/Downloads/180020009$ ./a.out sysad-XPS-13-9380
enter paragraph
I am Joshitha. I like computers.

sentences: 2
words: 6
characters: 32
sysad@sysad-XPS-13-9380:~/Downloads/180020009$ ./a.out sysad-XPS-13-9380
enter paragraph
Hi. This is Computer networks.

sentences: 2
words: 5
characters: 30
sysad@sysad-XPS-13-9380:~/Downloads/180020009$ ./a.out sysad-XPS-13-9380
enter paragraph

/
