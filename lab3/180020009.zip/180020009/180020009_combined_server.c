#include <arpa/inet.h> 
#include <errno.h> 
#include <netinet/in.h> 
#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <time.h>
#include <sys/wait.h>
#include <netdb.h>
//#define PORT 5000 
#define MAXLINE 1024 
#define MAXDATASIZE 10000
#define BACKLOG 10
#define MAXBUFLEN 100
int max(int x, int y) 
{ 
    if (x > y) 
        return x; 
    else
        return y; 
} 
int main(int argc,char *argv[]) 
{ 
    int listenfd, connfd, udpfd, nready, maxfdp1; 
    char buffer[MAXLINE]; 
    pid_t childpid; 
    fd_set rset; 
    ssize_t n; 
    socklen_t len; 
    const int on = 1; 
    struct sockaddr_in cliaddr, servaddr; 
    char* message = "Hello Client"; 
    void sig_chld(int); 
  
int sockfd, new_fd,numbytes,MYPORT,sock1fd;
MYPORT=atoi(argv[1]);
char buf[MAXDATASIZE];
struct sockaddr_in my_addr;
/* my address information */
struct sockaddr_in their_addr; /* client's address info */
int sin_size;
int addr_len;
if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
{
perror("socket");
exit(1);
}
my_addr.sin_family = AF_INET;
my_addr.sin_port = htons(MYPORT);
my_addr.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */
bzero(&(my_addr.sin_zero), 8);

if (bind(sockfd,(struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
{
perror("bind");
exit(1);
}

if (listen(sockfd, BACKLOG) == -1)
{
perror("listen");
exit(1);
}

if ((sock1fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
{
perror("socket");
exit(1);
}

if (bind(sock1fd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
{
perror("bind");
exit(1);
}

    // clear the descriptor set 
    FD_ZERO(&rset); 
  
    // get maxfd 
    maxfdp1 = max(sockfd, sock1fd) + 1; 
    for (;;) { 
  
        // set listenfd and udpfd in readset 
        FD_SET(sockfd, &rset); 
        FD_SET(sock1fd, &rset); 
  

        // select the ready descriptor 
        nready = select(maxfdp1, &rset, NULL, NULL, NULL); 
  
        // if tcp socket is readable then handle 
        // it by accepting the connection 
        if (FD_ISSET(sockfd, &rset)) { 

/* main accept() loop */

sin_size = sizeof(struct sockaddr_in);
if ((new_fd = accept(sockfd,(struct sockaddr *)&their_addr,&sin_size)) == -1)
{
perror("accept");
continue;
}
//printf("server: got connection from %d\n",inet_ntoa(their_addr.sin_addr));


    time_t mytime = time(NULL);
    char * time_str = ctime(&mytime);
    time_str[strlen(time_str)-1] = '\0';
  //  printf("Current Time : %s\n", time_str);

int len=strlen(time_str);
if (send(new_fd, time_str, len, 0) == -1)
perror("send");

//close(new_fd); /* parent doesn't need this */
while(waitpid(-1,NULL,WNOHANG) > 0); /* clean up child processes */
}

close(new_fd);

        
        // if udp socket is readable receive the message. 
        if (FD_ISSET(sock1fd, &rset)) { 

addr_len = sizeof(struct sockaddr);

if ((numbytes=recvfrom(sock1fd, buf, MAXBUFLEN, 0,
(struct sockaddr *)&their_addr, &addr_len)) == -1)
{
//perror("recvfrom");
exit(1);
}
//printf("got packet from %s\n",inet_ntoa(their_addr.sin_addr));
//printf("packet is %d bytes long\n",numbytes);
buf[numbytes] = '\0';
//printf("packet contains \"%s\"\n",buf);

struct hostent *ip;
ip=gethostbyname(buf);
char *a=inet_ntoa(*(struct in_addr *)ip->h_addr);
int l=strlen(a);
int i;
//printf("l %d\n",l);
//printf("IP %s\n", a);
if ((numbytes=sendto(sock1fd, a, l, 0,
(struct sockaddr *)&their_addr, sizeof(struct sockaddr))) == -1)
{
perror("sendto");
exit(1);

}
close(sock1fd);
   }
}

return 0;
} 


/*
sysad@sysad-XPS-13-9380:~/Downloads$ gcc 180020009_combined_server.c
sysad@sysad-XPS-13-9380:~/Downloads$ ./a.out 8000
/
