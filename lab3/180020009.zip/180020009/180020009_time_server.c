#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <time.h>

//#define MYPORT 3456
#define BACKLOG 10
#define MAXDATASIZE 10000
/* the port users will be connecting to */
/* number of pending connections */
int main(int argc,char *argv[])
{
int sockfd, new_fd,numbytes,MYPORT;
MYPORT=atoi(argv[1]);
char buf[MAXDATASIZE];
/* listen on sock_fd,
new connection on new_fd */
struct sockaddr_in my_addr;
/* my address information */
struct sockaddr_in their_addr; /* client's address info */
int sin_size;
if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
{
perror("socket");
exit(1);
}
my_addr.sin_family = AF_INET;
my_addr.sin_port = htons(MYPORT);
my_addr.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */
bzero(&(my_addr.sin_zero), 8);
/* zero the rest */
if (bind(sockfd,(struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
{
perror("bind");
exit(1);
}
if (listen(sockfd, BACKLOG) == -1)
{
perror("listen");
exit(1);
}
while(1)
/* main accept() loop */
{
sin_size = sizeof(struct sockaddr_in);
if ((new_fd = accept(sockfd,(struct sockaddr *)&their_addr,&sin_size)) == -1)
{
perror("accept");
continue;
}
printf("server: got connection from %d\n",inet_ntoa(their_addr.sin_addr));


    time_t mytime = time(NULL);
    char * time_str = ctime(&mytime);
    time_str[strlen(time_str)-1] = '\0';
  //  printf("Current Time : %s\n", time_str);

int len=strlen(time_str);
if (send(new_fd, time_str, len, 0) == -1)
perror("send");

//close(new_fd); /* parent doesn't need this */
while(waitpid(-1,NULL,WNOHANG) > 0); /* clean up child processes */
}
close(new_fd);
return 0;
}

/*
sysad@sysad-XPS-13-9380:~/Downloads$ gcc 180020009_time_server.c
sysad@sysad-XPS-13-9380:~/Downloads$ ./a.out 8000
*/
