#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

//#define MYPORT 4950
/* the port users will be sending to */
#define MAXBUFLEN 100
int main(int argc, char *argv[])
{
int sockfd;
struct sockaddr_in my_addr;
/* my address information */
struct sockaddr_in their_addr; /* client's address information */
int addr_len, numbytes,MYPORT;
MYPORT=atoi(argv[1]);
char buf[MAXBUFLEN];

if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
{
perror("socket");
exit(1);
}
my_addr.sin_family = AF_INET;
my_addr.sin_port = htons(MYPORT);
my_addr.sin_addr.s_addr = INADDR_ANY;
bzero(&(my_addr.sin_zero), 8);
if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
{
perror("bind");
exit(1);
}
addr_len = sizeof(struct sockaddr);
while(1){
if ((numbytes=recvfrom(sockfd, buf, MAXBUFLEN, 0,
(struct sockaddr *)&their_addr, &addr_len)) == -1)
{
perror("recvfrom");
exit(1);
}
//printf("got packet from %s\n",inet_ntoa(their_addr.sin_addr));
//printf("packet is %d bytes long\n",numbytes);
buf[numbytes] = '\0';
//printf("packet contains \"%s\"\n",buf);

struct hostent *ip;
ip=gethostbyname(buf);
char *a=inet_ntoa(*(struct in_addr *)ip->h_addr);
int l=strlen(a);
int i;
//printf("l %d\n",l);
//printf("IP %s\n", a);

if ((numbytes=sendto(sockfd, a, l, 0,
(struct sockaddr *)&their_addr, sizeof(struct sockaddr))) == -1)
{
perror("sendto");
exit(1);
}

}
close(sockfd);
return 0;
}

/*
sysad@sysad-XPS-13-9380:~/Downloads$ gcc 180020009_dns_server.c
sysad@sysad-XPS-13-9380:~/Downloads$ ./a.out 8000
*/
